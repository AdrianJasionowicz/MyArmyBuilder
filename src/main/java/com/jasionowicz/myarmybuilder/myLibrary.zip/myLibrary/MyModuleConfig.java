package com.jasionowicz.myarmybuilder.myLibrary;

public interface MyModuleConfig {

    boolean shouldLoad();
}
